<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;
use App\Models\Permission;

class RolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        $admin = Role::where('nom', 'ADMIN')->first();
        $respStock = Role::where('nom', 'RESP_STOCK')->first();
        $commercial = Role::where('nom', 'COMMERCIAL')->first();
        $magasinier = Role::where('nom', 'MAGASINIER')->first();
        $consultation = Role::where('nom', 'CONSULTATION')->first();

        // ADMIN : toutes les permissions
        if ($admin) {
            $admin->permissions()->sync(Permission::all()->pluck('id'));
        }

        // RESP_STOCK
        if ($respStock) {
            $codes = [
                // Unités (view)
                'config:unites:view',
                // Magasins (view)
                'config:magasins:view',
                // Catégories / Devises (view)
                'config:categories:view', 'config:devises:view',
                // Produits (view + gestion)
                'config:produits:view', 'config:produits:create', 'config:produits:update',
                // Historique prix (view + ajout)
                'config:historique_prix:view', 'config:historique_prix:create',
                // Lots (view + gestion + validation)
                'config:lots:view', 'config:lots:create', 'config:lots:update', 'config:lots:validate',
                // Types mouvement (view)
                'config:type_mouvement:view',
                // Mouvements (view + création + validation)
                'config:mouvements:view', 'config:mouvements:create', 'config:mouvements:validate',
                // Périodes inventaire (view + création + modification)
                'config:periode_inventaire:view', 'config:periode_inventaire:create', 'config:periode_inventaire:update',
                // Inventaires (view + création + modification)
                'config:inventaire:view', 'config:inventaire:create', 'config:inventaire:update',
                // Bons de commande (view + création + réception)
                'config:bon_commande:view', 'config:bon_commande:create', 'config:bon_commande:receive',
                // Retours (view + création + validation)
                'config:retours:view', 'config:retours:create', 'config:retours:validate',
                // Fiches techniques (view + création + modification)
                'config:fiche_technique:view', 'config:fiche_technique:create', 'config:fiche_technique:update',
                // Fiches techniques (menus) (view + création + modification)
                'config:fiche_technique_menu:view', 'config:fiche_technique_menu:create', 'config:fiche_technique_menu:update',
                // Recette (production)
                'config:recette:view', 'config:recette:create', 'config:recette:delete',
                // Partenaires (view)
                'config:partenaires:view',
                // Notifications
                'config:notifications:view', 'config:notifications:update',
                // Rapports
                'rapport:stock', 'rapport:commande', 'rapport:inventaire', 'rapport:client',
                // Traçabilité
                'config:tracabilite:view', 'config:tracabilite:create', 'config:tracabilite:update', 'config:tracabilite:delete',
                'config:cuisson:view', 'config:cuisson:create', 'config:cuisson:update', 'config:cuisson:delete',
                'config:atelier:view', 'config:atelier:create', 'config:atelier:update', 'config:atelier:delete',
                'config:suivi_chlore:view', 'config:suivi_chlore:create', 'config:suivi_chlore:update', 'config:suivi_chlore:delete',
                'config:controle_livraison:view', 'config:controle_livraison:create', 'config:controle_livraison:update', 'config:controle_livraison:delete',
            ];
            $respStock->permissions()->sync(Permission::whereIn('code', $codes)->pluck('id'));
        }

        // COMMERCIAL
        if ($commercial) {
            $codes = [
                // Unités (view)
                'config:unites:view',
                // Produits (view)
                'config:produits:view',
                // Partenaires (view + création)
                'config:partenaires:view', 'config:partenaires:create',
                // Départements (view) — requis pour la tracabilité
                'config:departements:view',
                // Devises (view) — requis pour les détails produit
                'config:devises:view',
                // Bons de commande (view + création)
                'config:bon_commande:view', 'config:bon_commande:create',
                // Avoirs (view + création)
                'facturation:avoir:view', 'facturation:avoir:create',
                // Lots (view) — requis pour la tracabilité
                'config:lots:view',
                // Notifications
                'config:notifications:view',
                // Rapports
                'rapport:commande', 'rapport:client',
                // Traçabilité
                'config:tracabilite:view', 'config:tracabilite:create',
                'config:cuisson:view', 'config:cuisson:create',
                'config:atelier:view', 'config:atelier:create',
                'config:suivi_chlore:view', 'config:suivi_chlore:create',
                'config:controle_livraison:view', 'config:controle_livraison:create',
            ];
            $commercial->permissions()->sync(Permission::whereIn('code', $codes)->pluck('id'));
        }

        // MAGASINIER
        if ($magasinier) {
            $codes = [
                // Unités / Magasins (view)
                'config:unites:view', 'config:magasins:view',
                // Catégories (view)
                'config:categories:view',
                // Produits (view)
                'config:produits:view',
                // Départements (view) — requis pour la tracabilité
                'config:departements:view',
                // Devises (view) — requis pour les détails produit
                'config:devises:view',
                // Lots (view + création)
                'config:lots:view', 'config:lots:create',
                // Mouvements (view + création)
                'config:mouvements:view', 'config:mouvements:create',
                // Périodes inventaire (view)
                'config:periode_inventaire:view',
                // Inventaires (view + création + modification)
                'config:inventaire:view', 'config:inventaire:create', 'config:inventaire:update',
                // Bons de commande (view + réception)
                'config:bon_commande:view', 'config:bon_commande:receive',
                // Retours (view + création)
                'config:retours:view', 'config:retours:create',
                // Fiches techniques (view)
                'config:fiche_technique:view',
                // Fiches techniques (menus) (view)
                'config:fiche_technique_menu:view',
                // Recette (production)
                'config:recette:view', 'config:recette:create',
                // Notifications
                'config:notifications:view', 'config:notifications:update',
                // Rapports
                'rapport:stock',
                // Traçabilité
                'config:tracabilite:view', 'config:tracabilite:create',
                'config:cuisson:view', 'config:cuisson:create',
                'config:atelier:view', 'config:atelier:create',
                'config:suivi_chlore:view', 'config:suivi_chlore:create',
                'config:controle_livraison:view', 'config:controle_livraison:create',
            ];
            $magasinier->permissions()->sync(Permission::whereIn('code', $codes)->pluck('id'));
        }

        // CONSULTATION
        if ($consultation) {
            $codes = [
                // Toutes les vues (lecture seule)
                'config:unites:view', 'config:magasins:view', 'config:departements:view',
                'config:categories:view',
                'config:devises:view', 'config:produits:view', 'config:lots:view',
                'config:type_mouvement:view', 'config:mouvements:view',
                'config:periode_inventaire:view', 'config:inventaire:view',
                'config:bon_commande:view', 'config:retours:view',
                'config:fiche_technique:view', 'config:recette:view', 'config:partenaires:view',
                'config:fiche_technique_menu:view',
                'config:historique_prix:view',
                'facturation:avoir:view',
                'config:notifications:view',
                // Rapports
                'rapport:stock', 'rapport:commande', 'rapport:client',
                'rapport:inventaire',
                // Traçabilité
                'config:tracabilite:view',
                'config:cuisson:view',
                'config:atelier:view',
                'config:suivi_chlore:view',
                'config:controle_livraison:view',
            ];
            $consultation->permissions()->sync(Permission::whereIn('code', $codes)->pluck('id'));
        }
    }
}
